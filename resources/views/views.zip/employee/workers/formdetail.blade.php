<div class="row"> 
		<div class="form-group"> 
			<label class="col-md-3 control-label text-right"> <strong> First Name: </strong></label>
			<div class="col-md-9">
				<label  class="control-label"> {!! $employee->first_name !!} </label>
			</div> 
		</div>
		
		<div class="form-group"> 
			<label class="col-md-3 control-label text-right"> <strong> Last Name: </strong></label>
			<div class="col-md-9">
				<label  class="control-label"> {!! $employee->last_name !!} </label>
			</div> 
		</div>
		 
		<div class="form-group"> 
			<label class="col-md-3 control-label text-right"> <strong> Phone: </strong></label>
			<div class="col-md-9">
				<label  class="control-label"> {!! $employee->phone !!} </label>
			</div> 
		</div>
		
		<div class="form-group"> 
			<label class="col-md-3 control-label text-right"> <strong> Email: </strong></label>
			<div class="col-md-9">
				<label  class="control-label"> {!! $employee->email !!} </label>
			</div> 
		</div>
		
</div>
				