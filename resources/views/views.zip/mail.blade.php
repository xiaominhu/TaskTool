<html>
<head> 
</head>
<body>
	<h3> Hi. </h3>
	<h3>  {!! $worker_name !!} has been updated on @if($type)service . @else maintenance . @endif </h3>
	<h3> Please check the following attachment. </h3>
</body>
</html>
