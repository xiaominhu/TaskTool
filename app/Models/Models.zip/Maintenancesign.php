<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Maintenancesign extends Model
{
    //
	protected $table = 'maintenancesign';
	protected $fillable = ['title', 'color']; 
}
